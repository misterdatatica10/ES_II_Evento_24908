using System.ComponentModel.DataAnnotations;

namespace EventosBackend.Data
{
    public class TipoUtilizador
    {
        [Key]
        public int Codigo { get; set; }

        [Required]
        [MaxLength(50)]
        public string Designacao { get; set; } = null!;

      public DateTime DataRegisto { get; set; }

  }
}
