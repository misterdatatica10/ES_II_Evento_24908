using System.ComponentModel.DataAnnotations;

namespace EventosBackend.Data
{
    public class Utilizador
    {
        [Key]
        public int Codigo { get; set; }

        [Required]
        [MaxLength(100)]
        public string Nome { get; set; } = null!;


        [MaxLength(100)]
        public string? Email { get; set; }

        [MaxLength(20)]
        public string? Telemovel { get; set; }

        [Required]
        [MaxLength(20)]
        public string UserName { get; set; } = null!;

        [Required]
        [MaxLength(20)]
        public string Password { get; set; } = null!;
        public int TipoUtilizadorCodigo { get; set; }
        public DateTime DataRegisto { get; set; }
  }
}
