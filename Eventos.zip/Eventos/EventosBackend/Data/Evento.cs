using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventosBackend.Data
{
    public class Evento : BaseClass
    {
        [Key]
        public int Codigo { get; set; }

        [Required]
        [MaxLength(50)]
        public string Nome { get; set; } = null!;

        [Required]
        public DateTime Data { get; set; }

        [Required]
        public TimeSpan Hora { get; set; }

        [Required]
        public int LocalidadeCodigo { get; set; }

        [ForeignKey("LocalidadeCodigo")]
        public virtual Localidade? Localidade { get; set; }

        [Required]
        public int CategoriaCodigo { get; set; }

        [ForeignKey("CategoriaCodigo")]
        public virtual Categoria? Categoria { get; set; }

        [Required]
        [MaxLength(250)]
        public string Descricao { get; set; } = null!;

        [Required]
        public int Capacidade { get; set; }

        [Required]
        public Decimal Preco { get; set; }

        [NotMapped]
        public List<TipoBilhete> TiposBilhete { get; set; } = new List<TipoBilhete>();

        [NotMapped]
        public List<Atividade> Atividades { get; set; } = new List<Atividade>();

        [Required]
        public int UtilizadorCodigo { get; set; }

        [ForeignKey("UtilizadorCodigo")]
        public virtual Utilizador? Organizador { get; set; }

        [NotMapped]
        public List<Participante> Participantes { get; set; } = new List<Participante>();
    }
}
