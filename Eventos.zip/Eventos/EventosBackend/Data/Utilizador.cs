using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventosBackend.Data
{
    public class Utilizador : BaseClass
    {
        [Key]
        public int Codigo { get; set; }

        [Required]
        [MaxLength(100)]
        public string Nome { get; set; } = null!;


        [MaxLength(100)]
        public string? Email { get; set; }

        [MaxLength(20)]
        public string? Telemovel { get; set; }

        [Required]
        [MaxLength(20)]
        public string UserName { get; set; } = null!;

        [Required]
        [MaxLength(20)]
        public string Password { get; set; } = null!;

        [Required]
        public int TipoUtilizadorCodigo { get; set; }

        [ForeignKey("TipoUtilizadorCodigo")]
        public virtual TipoUtilizador? TipoUtilizador { get; set; }

        [Required]
        public bool Organizar { get; set; }
    }
}
