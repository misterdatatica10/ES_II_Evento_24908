using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventosBackend.Data
{
    public class Mensagem : BaseClass
    {
        [Key]
        
        public int Codigo { get; set; }

        [Required]
        [MaxLength(30)]
        public string Assunto { get; set; } = null!;

        [Required]
        [MaxLength(250)]
        public string Descricao { get; set; } = null!;

        [Required]
        public int EventoCodigo { get; set; }

        [ForeignKey("EventoCodigo")]
        public virtual Evento? Evento { get; set; }
    }
}
