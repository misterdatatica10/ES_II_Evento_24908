using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventosBackend.Data
{
    public class Participante : BaseClass
    {
        [Key]
        public int Codigo { get; set; }

        [Required]
        public int UtilizadorCodigo { get; set; }

        [ForeignKey("UtilizadorCodigo")]
        public virtual Utilizador? Utilizador { get; set; }

        [Required]
        public int EventoCodigo { get; set; }

        [ForeignKey("EventoCodigo")]
        public virtual Evento? Evento { get; set; }

        [Required]
        public int TipoBilheteCodigo { get; set; }

        [ForeignKey("TipoBilheteCodigo")]
        public virtual TipoBilhete? TipoBilhete { get; set; }


    }
}
