using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventosBackend.Data
{
    public class Atividade : BaseClass
    {
        [Key]
        public int Codigo { get; set; }

        [Required]
        [MaxLength(50)]
        public string Nome { get; set; } = null!;

        [Required]
        public DateTime Data { get; set; }

        [Required]
        public TimeSpan Hora { get; set; }

        [Required]
        [MaxLength(250)]
        public string Descricao { get; set; } = null!;

        [Required]
        public int EventoCodigo { get; set; }

        [ForeignKey("EventoCodigo")]
        public virtual Evento? Evento { get; set; }

        [NotMapped]
        public List<Participante> Participantes { get; set; } = new List<Participante>();
    }
}
