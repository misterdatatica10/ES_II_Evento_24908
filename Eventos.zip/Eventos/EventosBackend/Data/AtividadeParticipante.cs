using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventosBackend.Data
{
    public class AtividadeParticipante : BaseClass
    {
        [Key]
        public int Codigo { get; set; }

        [Required]
        public int AtividadeCodigo { get; set; }

        [ForeignKey("AtividadeCodigo")]
        public virtual Atividade? Atividade { get; set; }

        [Required]
        public int ParticipanteCodigo { get; set; }

        [ForeignKey("ParticipanteCodigo")]
        public virtual Participante? Participante { get; set; }

  }
}
