using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.Serialization;

namespace EventosBackend.Data
{
    public class TipoBilhete : BaseClass
    {
        [Key]
        public int Codigo { get; set; }

        [MaxLength(50)]
        public string Designacao { get; set; } = null!;

        [Required]
        public int EventoCodigo { get; set; }

        [ForeignKey("EventoCodigo")]
        public virtual Evento? Evento { get; set; }

        [Required]
        public int TotalBilhetes { get; set; }

        [NotMapped]
        public List<Participante> Participantes { get; set; } = new List<Participante>();

        [Required]
        public Decimal Preco { get; set; }
  }
}
