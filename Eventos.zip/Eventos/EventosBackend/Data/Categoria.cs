﻿using System.ComponentModel.DataAnnotations;

namespace EventosBackend.Data
{
    public class Categoria : BaseClass
    {
        [Key]
        public int Codigo { get; set; }

        [Required]
        [MaxLength(50)]
        public string Designacao { get; set; } = null!;
    }
}
