using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventosBackend.Data
{
  public class Feedback : BaseClass
  {
    [Key]
    public int Codigo { get; set; }

    [Required]
    public int Rating { get; set; }

    [Required]
    public int UtilizadorCodigo { get; set; }

    [ForeignKey("UtilizadorCodigo")]
    public virtual Utilizador? Utilizador { get; set; }

    [Required]
    public int EventoCodigo { get; set; }

    [ForeignKey("EventoCodigo")]
    public virtual Evento? Evento { get; set; }

  }
}
