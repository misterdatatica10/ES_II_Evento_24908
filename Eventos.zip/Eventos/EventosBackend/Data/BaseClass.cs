﻿using System.ComponentModel;

namespace EventosBackend.Data
{
    public abstract class BaseClass
    {
        [DefaultValue(typeof(DateTime), "")]
        public DateTime DataRegisto { get; set; } = DateTime.UtcNow;
    }
}
