using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventosBackend.Data
{
    public class MensagemUtilizador : BaseClass
    {
        [Key]
        public int Codigo { get; set; }

        [Required]
        public int UtilizadorCodigo { get; set; }

        [ForeignKey("UtilizadorCodigo")]
        public virtual Utilizador? Utilizador { get; set; }

        [Required]
        public int MensagemCodigo { get; set; }

        [ForeignKey("MensagemCodigo")]
        public virtual Mensagem? Mensagem { get; set; }

        [Required]
        public bool Lida { get; set; }
    }
}
