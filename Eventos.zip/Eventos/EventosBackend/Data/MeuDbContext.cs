using EventosBackend.Data;
using Microsoft.EntityFrameworkCore;

public class MeuDbContext : DbContext
{
    public MeuDbContext(DbContextOptions<MeuDbContext> options) : base(options)
    {
    }

    public DbSet<TipoUtilizador> TipoUtilizador { get; set; }
    public DbSet<Utilizador> Utilizador { get; set; }
    public DbSet<Localidade> Localidade { get; set; }
    public DbSet<Categoria> Categoria { get; set; }
    public DbSet<Evento> Evento { get; set; }
    public DbSet<Participante> Participante { get; set; }
    public DbSet<Atividade> Atividade { get; set; }
    public DbSet<AtividadeParticipante> AtividadeParticipante { get; set; }
    public DbSet<Mensagem> Mensagem { get; set; }
    public DbSet<MensagemUtilizador> MensagemUtilizador { get; set; }
    public DbSet<TipoBilhete> TipoBilhete { get; set; }
    public DbSet<Feedback> Feedback { get; set; }


    // Outros conjuntos de entidades

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        DateTime dateNow = DateTime.Now;
        // Configurações adicionais, como chaves primárias, relacionamentos, etc.
        modelBuilder.Entity<TipoUtilizador>().HasData(
            new TipoUtilizador { Codigo = 1, Designacao = "Admin" },
            new TipoUtilizador { Codigo = 2, Designacao = "Useradmin"},
            new TipoUtilizador { Codigo = 3, Designacao = "User"}
        );

    base.OnModelCreating(modelBuilder);
    }
}
