﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace EventosBackend.Migrations
{
    /// <inheritdoc />
    public partial class Migration7 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Feedback",
                columns: table => new
                {
                    Codigo = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Rating = table.Column<int>(type: "integer", nullable: false),
                    UtilizadorCodigo = table.Column<int>(type: "integer", nullable: false),
                    EventoCodigo = table.Column<int>(type: "integer", nullable: false),
                    DataRegisto = table.Column<DateTime>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Feedback", x => x.Codigo);
                    table.ForeignKey(
                        name: "FK_Feedback_Evento_EventoCodigo",
                        column: x => x.EventoCodigo,
                        principalTable: "Evento",
                        principalColumn: "Codigo",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Feedback_Utilizador_UtilizadorCodigo",
                        column: x => x.UtilizadorCodigo,
                        principalTable: "Utilizador",
                        principalColumn: "Codigo",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.UpdateData(
                table: "TipoUtilizador",
                keyColumn: "Codigo",
                keyValue: 1,
                column: "DataRegisto",
                value: new DateTime(2023, 6, 14, 19, 7, 23, 167, DateTimeKind.Utc).AddTicks(2884));

            migrationBuilder.UpdateData(
                table: "TipoUtilizador",
                keyColumn: "Codigo",
                keyValue: 2,
                column: "DataRegisto",
                value: new DateTime(2023, 6, 14, 19, 7, 23, 167, DateTimeKind.Utc).AddTicks(2885));

            migrationBuilder.UpdateData(
                table: "TipoUtilizador",
                keyColumn: "Codigo",
                keyValue: 3,
                column: "DataRegisto",
                value: new DateTime(2023, 6, 14, 19, 7, 23, 167, DateTimeKind.Utc).AddTicks(2885));

            migrationBuilder.CreateIndex(
                name: "IX_Feedback_EventoCodigo",
                table: "Feedback",
                column: "EventoCodigo");

            migrationBuilder.CreateIndex(
                name: "IX_Feedback_UtilizadorCodigo",
                table: "Feedback",
                column: "UtilizadorCodigo");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Feedback");

            migrationBuilder.UpdateData(
                table: "TipoUtilizador",
                keyColumn: "Codigo",
                keyValue: 1,
                column: "DataRegisto",
                value: new DateTime(2023, 6, 14, 19, 5, 25, 369, DateTimeKind.Utc).AddTicks(6612));

            migrationBuilder.UpdateData(
                table: "TipoUtilizador",
                keyColumn: "Codigo",
                keyValue: 2,
                column: "DataRegisto",
                value: new DateTime(2023, 6, 14, 19, 5, 25, 369, DateTimeKind.Utc).AddTicks(6613));

            migrationBuilder.UpdateData(
                table: "TipoUtilizador",
                keyColumn: "Codigo",
                keyValue: 3,
                column: "DataRegisto",
                value: new DateTime(2023, 6, 14, 19, 5, 25, 369, DateTimeKind.Utc).AddTicks(6613));
        }
    }
}
