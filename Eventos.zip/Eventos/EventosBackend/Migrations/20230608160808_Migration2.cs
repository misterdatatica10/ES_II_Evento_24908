﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EventosBackend.Migrations
{
    /// <inheritdoc />
    public partial class Migration2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Participante_Atividade_AtividadeCodigo",
                table: "Participante");

            migrationBuilder.DropIndex(
                name: "IX_Participante_AtividadeCodigo",
                table: "Participante");

            migrationBuilder.DropColumn(
                name: "AtividadeCodigo",
                table: "Participante");

            migrationBuilder.UpdateData(
                table: "TipoUtilizador",
                keyColumn: "Codigo",
                keyValue: 1,
                column: "DataRegisto",
                value: new DateTime(2023, 6, 8, 16, 8, 8, 529, DateTimeKind.Utc).AddTicks(7187));

            migrationBuilder.UpdateData(
                table: "TipoUtilizador",
                keyColumn: "Codigo",
                keyValue: 2,
                column: "DataRegisto",
                value: new DateTime(2023, 6, 8, 16, 8, 8, 529, DateTimeKind.Utc).AddTicks(7188));

            migrationBuilder.UpdateData(
                table: "TipoUtilizador",
                keyColumn: "Codigo",
                keyValue: 3,
                column: "DataRegisto",
                value: new DateTime(2023, 6, 8, 16, 8, 8, 529, DateTimeKind.Utc).AddTicks(7188));
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "AtividadeCodigo",
                table: "Participante",
                type: "integer",
                nullable: true);

            migrationBuilder.UpdateData(
                table: "TipoUtilizador",
                keyColumn: "Codigo",
                keyValue: 1,
                column: "DataRegisto",
                value: new DateTime(2023, 6, 6, 20, 59, 11, 646, DateTimeKind.Utc).AddTicks(3127));

            migrationBuilder.UpdateData(
                table: "TipoUtilizador",
                keyColumn: "Codigo",
                keyValue: 2,
                column: "DataRegisto",
                value: new DateTime(2023, 6, 6, 20, 59, 11, 646, DateTimeKind.Utc).AddTicks(3128));

            migrationBuilder.UpdateData(
                table: "TipoUtilizador",
                keyColumn: "Codigo",
                keyValue: 3,
                column: "DataRegisto",
                value: new DateTime(2023, 6, 6, 20, 59, 11, 646, DateTimeKind.Utc).AddTicks(3129));

            migrationBuilder.CreateIndex(
                name: "IX_Participante_AtividadeCodigo",
                table: "Participante",
                column: "AtividadeCodigo");

            migrationBuilder.AddForeignKey(
                name: "FK_Participante_Atividade_AtividadeCodigo",
                table: "Participante",
                column: "AtividadeCodigo",
                principalTable: "Atividade",
                principalColumn: "Codigo");
        }
    }
}
