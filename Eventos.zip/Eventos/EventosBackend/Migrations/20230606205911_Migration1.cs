﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace EventosBackend.Migrations
{
    /// <inheritdoc />
    public partial class Migration1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Categoria",
                columns: table => new
                {
                    Codigo = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Designacao = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false),
                    DataRegisto = table.Column<DateTime>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Categoria", x => x.Codigo);
                });

            migrationBuilder.CreateTable(
                name: "Localidade",
                columns: table => new
                {
                    Codigo = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Designacao = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false),
                    DataRegisto = table.Column<DateTime>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Localidade", x => x.Codigo);
                });

            migrationBuilder.CreateTable(
                name: "TipoUtilizador",
                columns: table => new
                {
                    Codigo = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Designacao = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false),
                    DataRegisto = table.Column<DateTime>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TipoUtilizador", x => x.Codigo);
                });

            migrationBuilder.CreateTable(
                name: "Utilizador",
                columns: table => new
                {
                    Codigo = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Nome = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
                    Email = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: true),
                    Telemovel = table.Column<string>(type: "character varying(20)", maxLength: 20, nullable: true),
                    UserName = table.Column<string>(type: "character varying(20)", maxLength: 20, nullable: false),
                    Password = table.Column<string>(type: "character varying(20)", maxLength: 20, nullable: false),
                    TipoUtilizadorCodigo = table.Column<int>(type: "integer", nullable: false),
                    DataRegisto = table.Column<DateTime>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Utilizador", x => x.Codigo);
                    table.ForeignKey(
                        name: "FK_Utilizador_TipoUtilizador_TipoUtilizadorCodigo",
                        column: x => x.TipoUtilizadorCodigo,
                        principalTable: "TipoUtilizador",
                        principalColumn: "Codigo",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Evento",
                columns: table => new
                {
                    Codigo = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Nome = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false),
                    Data = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    Hora = table.Column<TimeSpan>(type: "interval", nullable: false),
                    LocalidadeCodigo = table.Column<int>(type: "integer", nullable: false),
                    CategoriaCodigo = table.Column<int>(type: "integer", nullable: false),
                    Descricao = table.Column<string>(type: "character varying(250)", maxLength: 250, nullable: false),
                    Capacidade = table.Column<int>(type: "integer", nullable: false),
                    Preco = table.Column<decimal>(type: "numeric", nullable: false),
                    UtilizadorCodigo = table.Column<int>(type: "integer", nullable: false),
                    DataRegisto = table.Column<DateTime>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Evento", x => x.Codigo);
                    table.ForeignKey(
                        name: "FK_Evento_Categoria_CategoriaCodigo",
                        column: x => x.CategoriaCodigo,
                        principalTable: "Categoria",
                        principalColumn: "Codigo",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Evento_Localidade_LocalidadeCodigo",
                        column: x => x.LocalidadeCodigo,
                        principalTable: "Localidade",
                        principalColumn: "Codigo",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Evento_Utilizador_UtilizadorCodigo",
                        column: x => x.UtilizadorCodigo,
                        principalTable: "Utilizador",
                        principalColumn: "Codigo",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "MensagemUtilizador",
                columns: table => new
                {
                    Codigo = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    UtilizadorCodigo = table.Column<int>(type: "integer", nullable: false),
                    Lida = table.Column<bool>(type: "boolean", nullable: false),
                    DataRegisto = table.Column<DateTime>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MensagemUtilizador", x => x.Codigo);
                    table.ForeignKey(
                        name: "FK_MensagemUtilizador_Utilizador_UtilizadorCodigo",
                        column: x => x.UtilizadorCodigo,
                        principalTable: "Utilizador",
                        principalColumn: "Codigo",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Atividade",
                columns: table => new
                {
                    Codigo = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Nome = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false),
                    Data = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    Hora = table.Column<TimeSpan>(type: "interval", nullable: false),
                    Descricao = table.Column<string>(type: "character varying(250)", maxLength: 250, nullable: false),
                    EventoCodigo = table.Column<int>(type: "integer", nullable: false),
                    DataRegisto = table.Column<DateTime>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Atividade", x => x.Codigo);
                    table.ForeignKey(
                        name: "FK_Atividade_Evento_EventoCodigo",
                        column: x => x.EventoCodigo,
                        principalTable: "Evento",
                        principalColumn: "Codigo",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Mensagem",
                columns: table => new
                {
                    Codigo = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Assunto = table.Column<string>(type: "character varying(30)", maxLength: 30, nullable: false),
                    Descricao = table.Column<string>(type: "character varying(250)", maxLength: 250, nullable: false),
                    UtilizadorCodigo = table.Column<int>(type: "integer", nullable: false),
                    EventoCodigo = table.Column<int>(type: "integer", nullable: false),
                    DataRegisto = table.Column<DateTime>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Mensagem", x => x.Codigo);
                    table.ForeignKey(
                        name: "FK_Mensagem_Evento_EventoCodigo",
                        column: x => x.EventoCodigo,
                        principalTable: "Evento",
                        principalColumn: "Codigo",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Mensagem_Utilizador_UtilizadorCodigo",
                        column: x => x.UtilizadorCodigo,
                        principalTable: "Utilizador",
                        principalColumn: "Codigo",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TipoBilhete",
                columns: table => new
                {
                    Codigo = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Designacao = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false),
                    EventoCodigo = table.Column<int>(type: "integer", nullable: false),
                    TotalBilhetes = table.Column<int>(type: "integer", nullable: false),
                    DataRegisto = table.Column<DateTime>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TipoBilhete", x => x.Codigo);
                    table.ForeignKey(
                        name: "FK_TipoBilhete_Evento_EventoCodigo",
                        column: x => x.EventoCodigo,
                        principalTable: "Evento",
                        principalColumn: "Codigo",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Participante",
                columns: table => new
                {
                    Codigo = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    UtilizadorCodigo = table.Column<int>(type: "integer", nullable: false),
                    EventoCodigo = table.Column<int>(type: "integer", nullable: false),
                    TipoBilheteCodigo = table.Column<int>(type: "integer", nullable: false),
                    AtividadeCodigo = table.Column<int>(type: "integer", nullable: true),
                    DataRegisto = table.Column<DateTime>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Participante", x => x.Codigo);
                    table.ForeignKey(
                        name: "FK_Participante_Atividade_AtividadeCodigo",
                        column: x => x.AtividadeCodigo,
                        principalTable: "Atividade",
                        principalColumn: "Codigo");
                    table.ForeignKey(
                        name: "FK_Participante_Evento_EventoCodigo",
                        column: x => x.EventoCodigo,
                        principalTable: "Evento",
                        principalColumn: "Codigo",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Participante_TipoBilhete_TipoBilheteCodigo",
                        column: x => x.TipoBilheteCodigo,
                        principalTable: "TipoBilhete",
                        principalColumn: "Codigo",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Participante_Utilizador_UtilizadorCodigo",
                        column: x => x.UtilizadorCodigo,
                        principalTable: "Utilizador",
                        principalColumn: "Codigo",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AtividadeParticipante",
                columns: table => new
                {
                    Codigo = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    AtividadeCodigo = table.Column<int>(type: "integer", nullable: false),
                    ParticipanteCodigo = table.Column<int>(type: "integer", nullable: false),
                    DataRegisto = table.Column<DateTime>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AtividadeParticipante", x => x.Codigo);
                    table.ForeignKey(
                        name: "FK_AtividadeParticipante_Atividade_AtividadeCodigo",
                        column: x => x.AtividadeCodigo,
                        principalTable: "Atividade",
                        principalColumn: "Codigo",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_AtividadeParticipante_Participante_ParticipanteCodigo",
                        column: x => x.ParticipanteCodigo,
                        principalTable: "Participante",
                        principalColumn: "Codigo",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "TipoUtilizador",
                columns: new[] { "Codigo", "DataRegisto", "Designacao" },
                values: new object[,]
                {
                    { 1, new DateTime(2023, 6, 6, 20, 59, 11, 646, DateTimeKind.Utc).AddTicks(3127), "Admin" },
                    { 2, new DateTime(2023, 6, 6, 20, 59, 11, 646, DateTimeKind.Utc).AddTicks(3128), "Useradmin" },
                    { 3, new DateTime(2023, 6, 6, 20, 59, 11, 646, DateTimeKind.Utc).AddTicks(3129), "User" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Atividade_EventoCodigo",
                table: "Atividade",
                column: "EventoCodigo");

            migrationBuilder.CreateIndex(
                name: "IX_AtividadeParticipante_AtividadeCodigo",
                table: "AtividadeParticipante",
                column: "AtividadeCodigo");

            migrationBuilder.CreateIndex(
                name: "IX_AtividadeParticipante_ParticipanteCodigo",
                table: "AtividadeParticipante",
                column: "ParticipanteCodigo");

            migrationBuilder.CreateIndex(
                name: "IX_Evento_CategoriaCodigo",
                table: "Evento",
                column: "CategoriaCodigo");

            migrationBuilder.CreateIndex(
                name: "IX_Evento_LocalidadeCodigo",
                table: "Evento",
                column: "LocalidadeCodigo");

            migrationBuilder.CreateIndex(
                name: "IX_Evento_UtilizadorCodigo",
                table: "Evento",
                column: "UtilizadorCodigo");

            migrationBuilder.CreateIndex(
                name: "IX_Mensagem_EventoCodigo",
                table: "Mensagem",
                column: "EventoCodigo");

            migrationBuilder.CreateIndex(
                name: "IX_Mensagem_UtilizadorCodigo",
                table: "Mensagem",
                column: "UtilizadorCodigo");

            migrationBuilder.CreateIndex(
                name: "IX_MensagemUtilizador_UtilizadorCodigo",
                table: "MensagemUtilizador",
                column: "UtilizadorCodigo");

            migrationBuilder.CreateIndex(
                name: "IX_Participante_AtividadeCodigo",
                table: "Participante",
                column: "AtividadeCodigo");

            migrationBuilder.CreateIndex(
                name: "IX_Participante_EventoCodigo",
                table: "Participante",
                column: "EventoCodigo");

            migrationBuilder.CreateIndex(
                name: "IX_Participante_TipoBilheteCodigo",
                table: "Participante",
                column: "TipoBilheteCodigo");

            migrationBuilder.CreateIndex(
                name: "IX_Participante_UtilizadorCodigo",
                table: "Participante",
                column: "UtilizadorCodigo");

            migrationBuilder.CreateIndex(
                name: "IX_TipoBilhete_EventoCodigo",
                table: "TipoBilhete",
                column: "EventoCodigo");

            migrationBuilder.CreateIndex(
                name: "IX_Utilizador_TipoUtilizadorCodigo",
                table: "Utilizador",
                column: "TipoUtilizadorCodigo");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AtividadeParticipante");

            migrationBuilder.DropTable(
                name: "Mensagem");

            migrationBuilder.DropTable(
                name: "MensagemUtilizador");

            migrationBuilder.DropTable(
                name: "Participante");

            migrationBuilder.DropTable(
                name: "Atividade");

            migrationBuilder.DropTable(
                name: "TipoBilhete");

            migrationBuilder.DropTable(
                name: "Evento");

            migrationBuilder.DropTable(
                name: "Categoria");

            migrationBuilder.DropTable(
                name: "Localidade");

            migrationBuilder.DropTable(
                name: "Utilizador");

            migrationBuilder.DropTable(
                name: "TipoUtilizador");
        }
    }
}
