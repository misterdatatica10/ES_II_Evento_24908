﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EventosBackend.Migrations
{
    /// <inheritdoc />
    public partial class Migration6 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "TipoUtilizador",
                keyColumn: "Codigo",
                keyValue: 1,
                column: "DataRegisto",
                value: new DateTime(2023, 6, 14, 19, 5, 25, 369, DateTimeKind.Utc).AddTicks(6612));

            migrationBuilder.UpdateData(
                table: "TipoUtilizador",
                keyColumn: "Codigo",
                keyValue: 2,
                column: "DataRegisto",
                value: new DateTime(2023, 6, 14, 19, 5, 25, 369, DateTimeKind.Utc).AddTicks(6613));

            migrationBuilder.UpdateData(
                table: "TipoUtilizador",
                keyColumn: "Codigo",
                keyValue: 3,
                column: "DataRegisto",
                value: new DateTime(2023, 6, 14, 19, 5, 25, 369, DateTimeKind.Utc).AddTicks(6613));
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "TipoUtilizador",
                keyColumn: "Codigo",
                keyValue: 1,
                column: "DataRegisto",
                value: new DateTime(2023, 6, 14, 19, 4, 24, 450, DateTimeKind.Utc).AddTicks(6244));

            migrationBuilder.UpdateData(
                table: "TipoUtilizador",
                keyColumn: "Codigo",
                keyValue: 2,
                column: "DataRegisto",
                value: new DateTime(2023, 6, 14, 19, 4, 24, 450, DateTimeKind.Utc).AddTicks(6245));

            migrationBuilder.UpdateData(
                table: "TipoUtilizador",
                keyColumn: "Codigo",
                keyValue: 3,
                column: "DataRegisto",
                value: new DateTime(2023, 6, 14, 19, 4, 24, 450, DateTimeKind.Utc).AddTicks(6246));
        }
    }
}
