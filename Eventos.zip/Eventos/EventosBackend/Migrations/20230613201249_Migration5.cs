﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EventosBackend.Migrations
{
    /// <inheritdoc />
    public partial class Migration5 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<decimal>(
                name: "Preco",
                table: "TipoBilhete",
                type: "numeric",
                nullable: false,
                defaultValue: 0m);

            migrationBuilder.UpdateData(
                table: "TipoUtilizador",
                keyColumn: "Codigo",
                keyValue: 1,
                column: "DataRegisto",
                value: new DateTime(2023, 6, 13, 20, 12, 49, 829, DateTimeKind.Utc).AddTicks(9773));

            migrationBuilder.UpdateData(
                table: "TipoUtilizador",
                keyColumn: "Codigo",
                keyValue: 2,
                column: "DataRegisto",
                value: new DateTime(2023, 6, 13, 20, 12, 49, 829, DateTimeKind.Utc).AddTicks(9774));

            migrationBuilder.UpdateData(
                table: "TipoUtilizador",
                keyColumn: "Codigo",
                keyValue: 3,
                column: "DataRegisto",
                value: new DateTime(2023, 6, 13, 20, 12, 49, 829, DateTimeKind.Utc).AddTicks(9774));
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Preco",
                table: "TipoBilhete");

            migrationBuilder.UpdateData(
                table: "TipoUtilizador",
                keyColumn: "Codigo",
                keyValue: 1,
                column: "DataRegisto",
                value: new DateTime(2023, 6, 13, 20, 7, 32, 199, DateTimeKind.Utc).AddTicks(2335));

            migrationBuilder.UpdateData(
                table: "TipoUtilizador",
                keyColumn: "Codigo",
                keyValue: 2,
                column: "DataRegisto",
                value: new DateTime(2023, 6, 13, 20, 7, 32, 199, DateTimeKind.Utc).AddTicks(2336));

            migrationBuilder.UpdateData(
                table: "TipoUtilizador",
                keyColumn: "Codigo",
                keyValue: 3,
                column: "DataRegisto",
                value: new DateTime(2023, 6, 13, 20, 7, 32, 199, DateTimeKind.Utc).AddTicks(2336));
        }
    }
}
