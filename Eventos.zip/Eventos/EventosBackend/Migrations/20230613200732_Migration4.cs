﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EventosBackend.Migrations
{
    /// <inheritdoc />
    public partial class Migration4 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Mensagem_Utilizador_UtilizadorCodigo",
                table: "Mensagem");

            migrationBuilder.DropIndex(
                name: "IX_Mensagem_UtilizadorCodigo",
                table: "Mensagem");

            migrationBuilder.DropColumn(
                name: "UtilizadorCodigo",
                table: "Mensagem");

            migrationBuilder.AddColumn<bool>(
                name: "Organizar",
                table: "Utilizador",
                type: "boolean",
                nullable: false,
                defaultValue: false);

            migrationBuilder.UpdateData(
                table: "TipoUtilizador",
                keyColumn: "Codigo",
                keyValue: 1,
                column: "DataRegisto",
                value: new DateTime(2023, 6, 13, 20, 7, 32, 199, DateTimeKind.Utc).AddTicks(2335));

            migrationBuilder.UpdateData(
                table: "TipoUtilizador",
                keyColumn: "Codigo",
                keyValue: 2,
                column: "DataRegisto",
                value: new DateTime(2023, 6, 13, 20, 7, 32, 199, DateTimeKind.Utc).AddTicks(2336));

            migrationBuilder.UpdateData(
                table: "TipoUtilizador",
                keyColumn: "Codigo",
                keyValue: 3,
                column: "DataRegisto",
                value: new DateTime(2023, 6, 13, 20, 7, 32, 199, DateTimeKind.Utc).AddTicks(2336));
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Organizar",
                table: "Utilizador");

            migrationBuilder.AddColumn<int>(
                name: "UtilizadorCodigo",
                table: "Mensagem",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.UpdateData(
                table: "TipoUtilizador",
                keyColumn: "Codigo",
                keyValue: 1,
                column: "DataRegisto",
                value: new DateTime(2023, 6, 8, 16, 46, 20, 953, DateTimeKind.Utc).AddTicks(7996));

            migrationBuilder.UpdateData(
                table: "TipoUtilizador",
                keyColumn: "Codigo",
                keyValue: 2,
                column: "DataRegisto",
                value: new DateTime(2023, 6, 8, 16, 46, 20, 953, DateTimeKind.Utc).AddTicks(7997));

            migrationBuilder.UpdateData(
                table: "TipoUtilizador",
                keyColumn: "Codigo",
                keyValue: 3,
                column: "DataRegisto",
                value: new DateTime(2023, 6, 8, 16, 46, 20, 953, DateTimeKind.Utc).AddTicks(7998));

            migrationBuilder.CreateIndex(
                name: "IX_Mensagem_UtilizadorCodigo",
                table: "Mensagem",
                column: "UtilizadorCodigo");

            migrationBuilder.AddForeignKey(
                name: "FK_Mensagem_Utilizador_UtilizadorCodigo",
                table: "Mensagem",
                column: "UtilizadorCodigo",
                principalTable: "Utilizador",
                principalColumn: "Codigo",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
