﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EventosBackend.Migrations
{
    /// <inheritdoc />
    public partial class Migration3 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "MensagemCodigo",
                table: "MensagemUtilizador",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.UpdateData(
                table: "TipoUtilizador",
                keyColumn: "Codigo",
                keyValue: 1,
                column: "DataRegisto",
                value: new DateTime(2023, 6, 8, 16, 46, 20, 953, DateTimeKind.Utc).AddTicks(7996));

            migrationBuilder.UpdateData(
                table: "TipoUtilizador",
                keyColumn: "Codigo",
                keyValue: 2,
                column: "DataRegisto",
                value: new DateTime(2023, 6, 8, 16, 46, 20, 953, DateTimeKind.Utc).AddTicks(7997));

            migrationBuilder.UpdateData(
                table: "TipoUtilizador",
                keyColumn: "Codigo",
                keyValue: 3,
                column: "DataRegisto",
                value: new DateTime(2023, 6, 8, 16, 46, 20, 953, DateTimeKind.Utc).AddTicks(7998));

            migrationBuilder.CreateIndex(
                name: "IX_MensagemUtilizador_MensagemCodigo",
                table: "MensagemUtilizador",
                column: "MensagemCodigo");

            migrationBuilder.AddForeignKey(
                name: "FK_MensagemUtilizador_Mensagem_MensagemCodigo",
                table: "MensagemUtilizador",
                column: "MensagemCodigo",
                principalTable: "Mensagem",
                principalColumn: "Codigo",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_MensagemUtilizador_Mensagem_MensagemCodigo",
                table: "MensagemUtilizador");

            migrationBuilder.DropIndex(
                name: "IX_MensagemUtilizador_MensagemCodigo",
                table: "MensagemUtilizador");

            migrationBuilder.DropColumn(
                name: "MensagemCodigo",
                table: "MensagemUtilizador");

            migrationBuilder.UpdateData(
                table: "TipoUtilizador",
                keyColumn: "Codigo",
                keyValue: 1,
                column: "DataRegisto",
                value: new DateTime(2023, 6, 8, 16, 8, 8, 529, DateTimeKind.Utc).AddTicks(7187));

            migrationBuilder.UpdateData(
                table: "TipoUtilizador",
                keyColumn: "Codigo",
                keyValue: 2,
                column: "DataRegisto",
                value: new DateTime(2023, 6, 8, 16, 8, 8, 529, DateTimeKind.Utc).AddTicks(7188));

            migrationBuilder.UpdateData(
                table: "TipoUtilizador",
                keyColumn: "Codigo",
                keyValue: 3,
                column: "DataRegisto",
                value: new DateTime(2023, 6, 8, 16, 8, 8, 529, DateTimeKind.Utc).AddTicks(7188));
        }
    }
}
