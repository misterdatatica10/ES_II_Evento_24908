using EventosBackend.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EventosBackend.Controllers
{
    [Route("api/[controller]")]
    public class AtividadeController : BaseController<Atividade>
    {
        public AtividadeController(MeuDbContext context) : base(context)
        {
        }
        public override async Task<ActionResult<IEnumerable<Atividade>>> GetAll()
        {
          var obj = await _context.Atividade
              .Include(o => o.Evento)
              .ToListAsync();

          return obj;
        }

        public override async Task<ActionResult<Atividade>> GetById(int codigo)
        {
          var obj = await _context.Atividade
              .Include(o => o.Evento)
              .FirstOrDefaultAsync(u => u.Codigo == codigo);

          if (obj == null)
            return NotFound();

            var participantesAtividade = await _context.AtividadeParticipante
                  .Where(t => t.AtividadeCodigo == codigo)
                  .Include(s => s.Participante)
                  .Select(s => s.Participante)
                  .ToListAsync();

              obj.Participantes = participantesAtividade;

            return obj;
        }
  }

}
