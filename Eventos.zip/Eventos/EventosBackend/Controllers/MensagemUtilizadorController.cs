using EventosBackend.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EventosBackend.Controllers
{
    [Route("api/[controller]")]
    public class MensagemUtilizadorController : BaseController<MensagemUtilizador>
    {
        public MensagemUtilizadorController(MeuDbContext context) : base(context)
        {
        }

        public override async Task<ActionResult<IEnumerable<MensagemUtilizador>>> GetAll()
        {
          var obj = await _context.MensagemUtilizador
              .Include(o => o.Utilizador)
              .Include(p => p.Mensagem)
              .ToListAsync();

          return obj;
        }

        public override async Task<ActionResult<MensagemUtilizador>> GetById(int codigo)
        {
          var obj = await _context.MensagemUtilizador
              .Include(o => o.Utilizador)
              .Include(p => p.Mensagem)
              .FirstOrDefaultAsync(u => u.Codigo == codigo);

          if (obj == null)
            return NotFound();


          return obj;
        }
  }

}
