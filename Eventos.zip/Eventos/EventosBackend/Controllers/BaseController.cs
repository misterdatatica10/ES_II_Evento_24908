using EventosBackend.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EventosBackend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BaseController<T> : ControllerBase where T : class
    {
        protected internal readonly MeuDbContext _context;

        public BaseController(MeuDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public virtual async Task<ActionResult<IEnumerable<T>>> GetAll()
        {
            var dbSet = _context.Set<T>();
            var obj = await dbSet.ToListAsync();

            return obj;
        }

        [HttpGet("{codigo}")]
        public virtual async Task<ActionResult<T>> GetById(int codigo)
        {
            var dbSet = _context.Set<T>();
            var obj = await dbSet.FindAsync(codigo);

            if (obj == null)
                return NotFound();

            return obj;
        }

        [HttpDelete("{codigo}")]
        public async Task<ActionResult> Delete(int codigo)
        {
            var dbSet = _context.Set<T>();

            var obj = await dbSet.FindAsync(codigo);
            if (obj == null)
                return NotFound();

            dbSet.Remove(obj);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        [HttpPost]
        public virtual async Task<ActionResult<T>> Create(T obj)
        {
            ConvertDateTimePropertiesToUtc(obj);
            _context.Set<T>().Add(obj);
      
            await _context.SaveChangesAsync();

            return obj;
        }

        [HttpPut("{codigo}")]
        public async Task<IActionResult> Update(int codigo, T obj)
        {
            var objCodigoProperty = typeof(T).GetProperty("Codigo"); 

            if (objCodigoProperty == null)
                return BadRequest("A classe não possui uma propriedade de identificação válida.");

            var objCodigoValue = objCodigoProperty.GetValue(obj);
            if (objCodigoValue == null || codigo != (int)objCodigoValue)
                return BadRequest();

            _context.Entry(obj).State = EntityState.Modified;

            try
            {
                var existingObj = await _context.FindAsync<T>(codigo);
                if (existingObj == null)
                    return NotFound();

                ConvertDateTimePropertiesToUtc(obj);


      await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                return NotFound();
            }

            return NoContent();
        }

        public static void ConvertDateTimePropertiesToUtc<T>(T obj)
        {
            foreach (var property in typeof(T).GetProperties())
            {
                if (property.PropertyType == typeof(DateTime))
                {
                    var dateTimeValue = (DateTime)property.GetValue(obj);
                    DateTime utcDateTime = DateTime.SpecifyKind(dateTimeValue, DateTimeKind.Utc);
                    property.SetValue(obj, utcDateTime);
                 }
            }
        }


   

  }
}
