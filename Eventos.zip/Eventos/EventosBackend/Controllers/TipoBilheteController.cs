using EventosBackend.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EventosBackend.Controllers
{
    [Route("api/[controller]")]
    public class TipoBilheteController : BaseController<TipoBilhete>
    {
        public TipoBilheteController(MeuDbContext context) : base(context)
        {
        }
        public override async Task<ActionResult<IEnumerable<TipoBilhete>>> GetAll()
        {
          var obj = await _context.TipoBilhete
              .Include(o => o.Evento)
              .ToListAsync();

          return obj;
        }

        public override async Task<ActionResult<TipoBilhete>> GetById(int codigo)
        {
          var obj = await _context.TipoBilhete
              .Include(o => o.Evento)
              .FirstOrDefaultAsync(u => u.Codigo == codigo);

          if (obj == null)
            return NotFound();

          var participantesTipoBilhete = await _context.Participante
                .Where(t => t.TipoBilheteCodigo == codigo)
                .ToListAsync();
          obj.Participantes = participantesTipoBilhete;

          return obj;
        }
  }

}
