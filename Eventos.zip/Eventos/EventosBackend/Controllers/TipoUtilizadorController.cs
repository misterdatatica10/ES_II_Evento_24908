﻿using EventosBackend.Data;
using Microsoft.AspNetCore.Mvc;

namespace EventosBackend.Controllers
{
    [Route("api/[controller]")]
    public class TipoUtilizadorController : BaseController<TipoUtilizador>
    {
        public TipoUtilizadorController(MeuDbContext context) : base(context)
        {
        }
    }

}
