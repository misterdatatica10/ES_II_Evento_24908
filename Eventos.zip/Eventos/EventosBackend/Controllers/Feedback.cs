using EventosBackend.Controllers;
using EventosBackend.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EventosBackend.Controllers
{
      [Route("api/[controller]")]
      public class FeedbackController : BaseController<Feedback>
      {
           public FeedbackController(MeuDbContext context) : base(context)
           {
           }
           public override async Task<ActionResult<IEnumerable<Feedback>>> GetAll()
           {
               var obj = await _context.Feedback
                    .Include(u => u.Utilizador)
                    .Include(e => e.Evento)
                    .ToListAsync();

               return obj;
           }

          public override async Task<ActionResult<Feedback>> GetById(int codigo)
          {
                var obj = await _context.Feedback
                    .Include(u => u.Utilizador)
                    .Include(e => e.Evento)
                    .FirstOrDefaultAsync(u => u.Codigo == codigo);

                if (obj == null)
                    return NotFound();

                return obj;
          }
      }

}
