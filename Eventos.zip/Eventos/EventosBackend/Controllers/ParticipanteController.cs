using EventosBackend.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EventosBackend.Controllers
{
    [Route("api/[controller]")]
    public class ParticipanteController : BaseController<Participante>
    {
        public ParticipanteController(MeuDbContext context) : base(context)
        {
        }

        public override async Task<ActionResult<IEnumerable<Participante>>> GetAll()
        {
          var obj = await _context.Participante
              .Include(o => o.Utilizador)
              .Include(o => o.TipoBilhete)
              .Include(o => o.Evento)
              .ToListAsync();

          return obj;
        }

        public override async Task<ActionResult<Participante>> GetById(int codigo)
        {
          var obj = await _context.Participante
              .Include(o => o.Utilizador)
              .Include(o => o.TipoBilhete)
              .Include(o => o.Evento)
              .FirstOrDefaultAsync(u => u.Codigo == codigo);

          if (obj == null)
            return NotFound();

          return obj;
        }
  }

}
