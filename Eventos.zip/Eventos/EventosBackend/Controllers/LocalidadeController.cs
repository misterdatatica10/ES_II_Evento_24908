﻿using EventosBackend.Data;
using Microsoft.AspNetCore.Mvc;

namespace EventosBackend.Controllers
{
    [Route("api/[controller]")]
    public class LocalidadeController : BaseController<Localidade>
    {
        public LocalidadeController(MeuDbContext context) : base(context)
        {
        }
    }

}