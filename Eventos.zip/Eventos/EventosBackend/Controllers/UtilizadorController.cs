using EventosBackend.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EventosBackend.Controllers
{
    [Route("api/[controller]")]
    public class UtilizadorController : BaseController<Utilizador>
    {
      public UtilizadorController(MeuDbContext context) : base(context)
      {
      }
      public override async Task<ActionResult<IEnumerable<Utilizador>>> GetAll()
      {
        var utilizadores = await _context.Utilizador
            .Include(u => u.TipoUtilizador)
            .ToListAsync();

        return utilizadores;
      }

      public override async Task<ActionResult<Utilizador>> GetById(int codigo)
      {
        var utilizador = await _context.Utilizador
            .Include(u => u.TipoUtilizador)
            .FirstOrDefaultAsync(u => u.Codigo == codigo);

        if (utilizador == null)
          return NotFound();
        

        return utilizador;
      }

      public override async Task<ActionResult<Utilizador>> Create(Utilizador obj)
      {
        ConvertDateTimePropertiesToUtc(obj);

        // Se Utilizador já existir // Inicio
        string adminUsername = "admin";
        string adminPassword = "admin";
        if (obj.UserName == adminUsername)
          return BadRequest("Username já existe");

         var utilizador = await _context.Utilizador.
        FirstOrDefaultAsync(u => u.UserName == obj.UserName);
        if (utilizador != null)
          return BadRequest("Username já existe");
      // Se Utilizador já existir // Fim

      _context.Set<Utilizador>().Add(obj);

        await _context.SaveChangesAsync();

        return obj;
      }


    [HttpPost("login")]
      public async Task<ActionResult<Utilizador>> Login(Dictionary<string, object> credenciais)
      {
          if (credenciais["username"] == null)
            return BadRequest("Credenciais inválidas.");
          if (credenciais["password"] == null)
            return BadRequest("Credenciais inválidas.");

        string? username = credenciais["username"].ToString();
        string? password = credenciais["password"].ToString();

        string adminUsername = "admin";
        string adminPassword = "admin";
        if (username == adminUsername && password == adminPassword)
        {
          var admin = new Utilizador();
          admin.TipoUtilizadorCodigo = 1;
          return admin;
        }

        // Verificar as credenciais do usuário no banco de dados
        var utilizador = await _context.Utilizador
            .FirstOrDefaultAsync(u => u.UserName == username && u.Password == password);

        if (utilizador == null)
          return BadRequest("Credenciais inválidas.");

        return utilizador;
      }

  }
    
}
