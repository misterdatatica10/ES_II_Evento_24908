﻿using EventosBackend.Data;
using Microsoft.AspNetCore.Mvc;

namespace EventosBackend.Controllers
{
    [Route("api/[controller]")]
    public class CategoriaController : BaseController<Categoria>
    {
        public CategoriaController(MeuDbContext context) : base(context)
        {
        }
    }

}