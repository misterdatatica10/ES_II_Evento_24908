using EventosBackend.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Reflection;

namespace EventosBackend.Controllers
{
    [Route("api/[controller]")]
    public class EventoController : BaseController<Evento>
    {
        public EventoController(MeuDbContext context) : base(context)
        {
        }
        public override async Task<ActionResult<IEnumerable<Evento>>> GetAll()
        {
          var obj = await _context.Evento
              .Include(o => o.Organizador)
              .Include(c => c.Categoria)
              .Include(l => l.Localidade)
              .ToListAsync();

          return obj;
        }

        public override async Task<ActionResult<Evento>> GetById(int codigo)
        {
          var obj = await _context.Evento
              .Include(o => o.Organizador)
              .Include(c => c.Categoria)
              .Include(l => l.Localidade)
              .FirstOrDefaultAsync(u => u.Codigo == codigo);

          if (obj == null)
                return NotFound();

            var tipoBilhetesEvento = await _context.TipoBilhete
                    .Where(t => t.EventoCodigo == codigo)
                    .ToListAsync();
            var atividadesEvento = await _context.Atividade
                    .Where(t => t.EventoCodigo == codigo)
                    .ToListAsync();
            var participantesEvento = await _context.Participante
                    .Where(t => t.EventoCodigo == codigo)
                    .ToListAsync();

            obj.TiposBilhete = tipoBilhetesEvento;
            obj.Atividades = atividadesEvento;
            obj.Participantes = participantesEvento;

            return obj;
        }
  }

}
