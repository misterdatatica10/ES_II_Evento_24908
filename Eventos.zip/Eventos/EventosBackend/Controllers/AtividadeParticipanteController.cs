using EventosBackend.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EventosBackend.Controllers
{
    [Route("api/[controller]")]
    public class AtividadeParticipanteController : BaseController<AtividadeParticipante>
    {
        public AtividadeParticipanteController(MeuDbContext context) : base(context)
        {
        }

        public override async Task<ActionResult<IEnumerable<AtividadeParticipante>>> GetAll()
        {
          var obj = await _context.AtividadeParticipante
              .Include(o => o.Atividade)
              .Include(p => p.Participante)
              .ToListAsync();

          return obj;
        }

        public override async Task<ActionResult<AtividadeParticipante>> GetById(int codigo)
        {
          var obj = await _context.AtividadeParticipante
              .Include(o => o.Atividade)
              .Include(p => p.Participante)
              .FirstOrDefaultAsync(u => u.Codigo == codigo);

          if (obj == null)
            return NotFound();


          return obj;
        }
  }

}
