using EventosBackend.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EventosBackend.Controllers
{
    [Route("api/[controller]")]
    public class MensagemController : BaseController<Mensagem>
    {
        public MensagemController(MeuDbContext context) : base(context)
        {
        }

    public override async Task<ActionResult<IEnumerable<Mensagem>>> GetAll()
    {
      var obj = await _context.Mensagem
          .Include(o => o.Evento)
          .ToListAsync();

      return obj;
    }

    public override async Task<ActionResult<Mensagem>> GetById(int codigo)
    {
      var obj = await _context.Mensagem
          .Include(o => o.Evento)
          .FirstOrDefaultAsync(u => u.Codigo == codigo);

      if (obj == null)
        return NotFound();

      return obj;
    }
  }

}
